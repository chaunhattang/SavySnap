/** @format */

'use client';
import '@ant-design/v5-patch-for-react-19';
import store from '@/stores';
import { Provider } from 'react-redux';

const ReduxProvider = ({ children }: { children: React.ReactNode }) => {
    return <Provider store={store}>{children}</Provider>;
};

export default ReduxProvider;
